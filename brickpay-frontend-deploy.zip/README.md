# BrickPay Frontend

Deployed with Vercel.

To run locally:
```bash
npm install
npm run dev
```